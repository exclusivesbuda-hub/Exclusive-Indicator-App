# Exclusive Indicator Android App

This is the Android app project for Exclusive Indicator.

The app opens the existing live Exclusive Indicator website inside a native Android WebView:
https://exclusiveindicatorv-8.netlify.app/

Build with Android Studio or another Android Gradle build environment:
./gradlew assembleDebug

The resulting APK will be under:
app/build/outputs/apk/debug/app-debug.apk

No trading credentials are embedded in the app.
